param([ValidateSet('Open', 'Start', 'Stop', 'Status')][string]$Action = 'Open')
$ErrorActionPreference = 'Stop'
$taskRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$taskRuntime = Join-Path $taskRoot '.runtime'
$taskSessionFile = Join-Path $taskRuntime 'report-session.json'
if (-not (Test-Path -LiteralPath $taskRuntime)) { New-Item -ItemType Directory -Path $taskRuntime | Out-Null }
function Invoke-ReportLocal([string]$Path, [string]$Method = 'GET') {
    $taskSession = Get-Content -LiteralPath $taskSessionFile -Raw | ConvertFrom-Json
    if ($taskSession.baseUrl -ne 'http://127.0.0.1:8766' -or $taskSession.reportKey -notmatch '^[a-f0-9]{64}$') { throw 'Invalid report session.' }
    $taskRequest = [System.Net.HttpWebRequest]::Create($taskSession.baseUrl + $Path)
    $taskRequest.Proxy = $null
    $taskRequest.Timeout = 2000
    $taskRequest.Method = $Method
    if ($Method -eq 'POST') { $taskRequest.ContentLength = 0 }
    $taskRequest.Headers.Add('Authorization', "Bearer $($taskSession.reportKey)")
    $taskResponse = $taskRequest.GetResponse()
    try {
        $taskReader = [System.IO.StreamReader]::new($taskResponse.GetResponseStream())
        try { return ($taskReader.ReadToEnd() | ConvertFrom-Json) } finally { $taskReader.Dispose() }
    } finally { $taskResponse.Close() }
}
try {
    $taskHealthy = $false
    try { $taskHealthy = (Invoke-ReportLocal '/api/health').app -eq 'mes-flag-report' } catch {}
    if ($Action -eq 'Stop') {
        if ($taskHealthy) { Invoke-ReportLocal '/api/stop' 'POST' | Out-Null; Write-Output 'Flag report stopped.' }
        else { Write-Output 'No authenticated flag report server is running.' }
        exit 0
    }
    if ($Action -eq 'Status') { Write-Output "Flag report running: $taskHealthy"; exit 0 }
    & (Join-Path $taskRoot 'Manage-MES-API.ps1') -Action Start
    if (-not $taskHealthy) {
        $taskNode = Join-Path $taskRoot 'runtime\node.exe'
            if (-not (Test-Path -LiteralPath $taskNode)) { $taskNode = (Get-Command node.exe -ErrorAction Stop).Source }
        $taskScript = Join-Path $taskRoot 'report-server.mjs'
        $taskChild = Start-Process -FilePath $taskNode -ArgumentList ('"' + $taskScript + '"') -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskRuntime 'report.stdout.log') -RedirectStandardError (Join-Path $taskRuntime 'report.stderr.log')
        for ($taskAttempt = 0; $taskAttempt -lt 30; $taskAttempt++) {
            try { $taskHealthy = (Invoke-ReportLocal '/api/health').app -eq 'mes-flag-report' } catch {}
            if ($taskHealthy) { break }
            $taskChild.Refresh()
            if ($taskChild.HasExited) { break }
            Start-Sleep -Milliseconds 200
        }
        if (-not $taskHealthy) { throw 'Report startup failed. See .runtime\report.stderr.log.' }
    }
    if ($Action -eq 'Open') {
        $taskSession = Get-Content -LiteralPath $taskSessionFile -Raw | ConvertFrom-Json
        Start-Process -FilePath ($taskSession.baseUrl + '/#key=' + $taskSession.reportKey)
    }
    Write-Output 'Flag report is ready.'
} catch {
    Add-Content -LiteralPath (Join-Path $taskRuntime 'report-launcher.log') -Value "$(Get-Date -Format o) $($_.Exception.Message)"
    Write-Error $_.Exception.Message
    exit 1
}
