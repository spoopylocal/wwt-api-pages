param([ValidateSet('Start', 'Stop', 'Status')][string]$Action = 'Start')
$ErrorActionPreference = 'Stop'
$taskRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$taskServer = Join-Path $taskRoot 'server.mjs'
$taskRuntime = Join-Path $taskRoot '.runtime'
$taskStateFile = Join-Path $taskRuntime 'server-process.json'
$taskSessionFile = Join-Path $taskRoot '.local-session.json'
if (-not (Test-Path -LiteralPath $taskRuntime)) { New-Item -ItemType Directory -Path $taskRuntime | Out-Null }

function Write-TaskStatus([string]$Message) {
    Add-Content -LiteralPath (Join-Path $taskRuntime 'launcher.log') -Value "$(Get-Date -Format o) $Message"
    Write-Output $Message
}

function Get-TaskOwnedProcess {
    if (-not (Test-Path -LiteralPath $taskStateFile)) { return $null }
    $taskState = Get-Content -LiteralPath $taskStateFile -Raw | ConvertFrom-Json
    if ($taskState.ScriptPath -ne $taskServer -or [int]$taskState.ProcessId -le 0) { throw 'Saved process identity does not match this MES-API folder.' }
    $taskProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $([int]$taskState.ProcessId)"
    if ($null -eq $taskProcess) { return $null }
    # PowerShell 7 may deserialize ISO JSON dates directly as DateTime. Avoid
    # stringifying it, which discards fractional seconds and the UTC offset.
    $taskStart = if ($taskState.CreatedUtc -is [DateTime]) { $taskState.CreatedUtc.ToUniversalTime() }
        else { [DateTimeOffset]::Parse($taskState.CreatedUtc).UtcDateTime }
    if ($taskProcess.Name -ne 'node.exe' -or $taskProcess.CreationDate.ToUniversalTime().Ticks -ne $taskStart.Ticks) {
        throw 'The saved PID belongs to a different process. It will not be touched.'
    }
    return $taskProcess
}

function Invoke-TaskLocal([string]$Path, [string]$Method = 'GET') {
    $taskSession = Get-Content -LiteralPath $taskSessionFile -Raw | ConvertFrom-Json
    if ($taskSession.baseUrl -ne 'http://127.0.0.1:8765') { throw 'Unexpected local server address.' }
    $taskRequest = [System.Net.HttpWebRequest]::Create('http://127.0.0.1:8765' + $Path)
    $taskRequest.Proxy = $null
    $taskRequest.Timeout = 2000
    $taskRequest.Method = $Method
    if ($Method -eq 'POST') { $taskRequest.ContentLength = 0 }
    $taskRequest.Headers.Add('Authorization', "Bearer $($taskSession.clientKey)")
    $taskResponse = $taskRequest.GetResponse()
    try {
        $taskReader = [System.IO.StreamReader]::new($taskResponse.GetResponseStream())
        try { return ($taskReader.ReadToEnd() | ConvertFrom-Json) }
        finally { $taskReader.Dispose() }
    } finally { $taskResponse.Close() }
}

function Test-TaskPort {
    $taskSocket = [System.Net.Sockets.TcpClient]::new()
    try {
        $taskConnect = $taskSocket.BeginConnect('127.0.0.1', 8765, $null, $null)
        if (-not $taskConnect.AsyncWaitHandle.WaitOne(500)) { return $false }
        $taskSocket.EndConnect($taskConnect)
        return $true
    } catch { return $false }
    finally { $taskSocket.Dispose() }
}

$taskHasher = [System.Security.Cryptography.SHA256]::Create()
try { $taskRootHash = [BitConverter]::ToString($taskHasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($taskRoot))).Replace('-', '').Substring(0, 20) }
finally { $taskHasher.Dispose() }
$taskMutex = [System.Threading.Mutex]::new($false, "Local\MES_API_$taskRootHash")
$taskLockHeld = $false
try {
    try { $taskLockHeld = $taskMutex.WaitOne(10000) }
    catch [System.Threading.AbandonedMutexException] { $taskLockHeld = $true }
    if (-not $taskLockHeld) { throw 'Another MES-API start/stop operation is still running.' }
    $taskOwned = Get-TaskOwnedProcess
    switch ($Action) {
        'Start' {
            if ($null -ne $taskOwned) {
                Invoke-TaskLocal '/health' | Out-Null
                Write-TaskStatus 'MES-API is already running in the background.'
                break
            }
            if (Test-TaskPort) { throw 'Port 8765 is already in use. Stop the previous foreground bridge once, then start this background copy.' }
            $taskNode = Join-Path $taskRoot 'runtime\node.exe'
            if (-not (Test-Path -LiteralPath $taskNode)) { $taskNode = (Get-Command node.exe -ErrorAction Stop).Source }
            $taskChild = Start-Process -FilePath $taskNode -ArgumentList ('"' + $taskServer + '" --managed') -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskRuntime 'server.stdout.log') -RedirectStandardError (Join-Path $taskRuntime 'server.stderr.log')
            $taskIdentity = Get-CimInstance Win32_Process -Filter "ProcessId = $($taskChild.Id)"
            if ($null -eq $taskIdentity) { throw 'The server exited during startup. See .runtime\server.stderr.log.' }
            [pscustomobject]@{ ProcessId = $taskChild.Id; CreatedUtc = $taskIdentity.CreationDate.ToUniversalTime().ToString('o'); ScriptPath = $taskServer } |
                ConvertTo-Json | Set-Content -LiteralPath $taskStateFile -Encoding UTF8
            $taskHealthy = $false
            for ($taskAttempt = 0; $taskAttempt -lt 30; $taskAttempt++) {
                $taskChild.Refresh()
                if ($taskChild.HasExited) { break }
                try { $taskHealth = Invoke-TaskLocal '/health'; $taskHealthy = $taskHealth.managed -and $taskHealth.processId -eq $taskChild.Id } catch {}
                if ($taskHealthy) { break }
                Start-Sleep -Milliseconds 200
            }
            if (-not $taskHealthy) { throw 'Server startup did not complete. See .runtime\server.stderr.log.' }
            Write-TaskStatus 'MES-API started in the background on http://127.0.0.1:8765.'
        }
        'Stop' {
            if ($null -eq $taskOwned) { Write-TaskStatus 'No managed server is running.'; break }
            $taskHealth = Invoke-TaskLocal '/health'
            if (-not $taskHealth.managed -or $taskHealth.processId -ne $taskOwned.ProcessId) {
                throw "This server predates managed shutdown. End node.exe PID $($taskOwned.ProcessId) once in Task Manager, then use Start-MES-API.vbs."
            }
            # Authenticated application shutdown; no process termination rights needed.
            Invoke-TaskLocal '/control/stop' 'POST' | Out-Null
            for ($taskWait = 0; $taskWait -lt 40; $taskWait++) {
                if (-not (Get-Process -Id $taskOwned.ProcessId -ErrorAction SilentlyContinue)) { break }
                Start-Sleep -Milliseconds 250
            }
            if (Get-Process -Id $taskOwned.ProcessId -ErrorAction SilentlyContinue) { throw 'The server has not finished shutting down yet.' }
            Remove-Item -LiteralPath $taskStateFile -ErrorAction SilentlyContinue
            Write-TaskStatus 'MES-API background server stopped.'
        }
        'Status' {
            if ($null -ne $taskOwned) { Invoke-TaskLocal '/health' | Out-Null; Write-TaskStatus 'MES-API is running in the background.' }
            elseif (Test-TaskPort) { Write-TaskStatus 'Port 8765 is in use by another server.' }
            else { Write-TaskStatus 'MES-API is stopped.' }
        }
    }
} catch {
    Write-TaskStatus "ERROR: $($_.Exception.Message)"
    exit 1
} finally {
    if ($taskLockHeld) { $taskMutex.ReleaseMutex() }
    $taskMutex.Dispose()
}
